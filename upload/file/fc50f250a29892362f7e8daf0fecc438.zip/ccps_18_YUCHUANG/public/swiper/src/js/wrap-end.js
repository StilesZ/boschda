    window.Swiper = Swiper;
})();
